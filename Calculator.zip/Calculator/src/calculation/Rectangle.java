package calculation;

public class Rectangle {

    int sideA;
    int sideB;

    public Rectangle(int sideACm, int sideBCm){
        sideA = sideACm;
        sideB = sideBCm;

    }

    public int rectangleAreaCalc() {

        int rectangleAreaCm = sideA * sideB;

        return rectangleAreaCm;


    }


}
