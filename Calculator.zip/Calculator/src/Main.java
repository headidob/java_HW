import calculation.Rectangle;

import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Если хотите расчитать площадь прямоугольника то введите: 1, " +
                "если параллелограмма, то: любое другое число");
        byte yesNo = scanner.nextByte();
        if (yesNo == 1) {
            System.out.println("Введите ширину прямоугольника в см:");
            int sideACm = scanner.nextInt(); // Поучить высоту стены в мм
            System.out.println("Введите длину прямоугольника в см:");
            int sideBCm = scanner.nextInt(); // Поучить длину стены в мм

            Rectangle rectangle = new Rectangle(sideACm, sideBCm);
            int recAr = rectangle.rectangleAreaCalc();

            System.out.println("Площадь прямоугольника = " + recAr + " см2");
        } else {
            // формула параллелограмма такая же как и прямоугольника, только там берется не 2 стороны, а 1 длинная сторона и высота

            System.out.println("Введите длиную сторону параллелограмма в см:");
            int sideBCm = scanner.nextInt(); // Поучить длину стены в мм
            System.out.println("Введите высоту параллелограмма в см:");
            int sideACm = scanner.nextInt(); // Поучить высоту стены в мм


            Rectangle rectangle = new Rectangle(sideACm, sideBCm);
            int recAr = rectangle.rectangleAreaCalc();

            System.out.println("Площадь параллелограмма = " + recAr + " см2");
                    }
    }
}